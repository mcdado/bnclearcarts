# Clear Carts

PrestaShop module to avoid abandoned cart reminders to a customer when he/she places an order with a new cart.

## Credits

Made by [Brand New srl](http://brandnew.sm).
