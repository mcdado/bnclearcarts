# Clear Carts

Clear carts for a customer when an order is made by such customer.

## Credits

Made by [Brand New srl](http://brandnew.sm).
